import React, { useState } from 'react';
import './App.css';

function App() {
  const [file, setFile] = useState(null);
  const [forecast, setForecast] = useState([]);

  const uploadFile = async () => {
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch("http://localhost:8000/forecast", {
      method: "POST",
      body: formData
    });
    const data = await res.json();
    setForecast(data.forecast);
  };

  return (
    <div className="App">
      <h2>Workload Forecaster</h2>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={uploadFile}>Upload and Forecast</button>
      <ul>
        {forecast.map((item, idx) => (
          <li key={idx}>{item.date}: {item.forecast}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
