import React, { useState } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

function App() {
  const [file, setFile] = useState(null);
  const [forecast, setForecast] = useState("");
  const [chartData, setChartData] = useState(null);

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append("file", file);
    const res = await axios.post("http://localhost:8000/forecast", formData);
    setForecast(res.data.forecast_text);

    const lines = res.data.forecast_text.match(/\d{4}-\d{2}-\d{2}:\s*\d+/g);
    if (lines) {
      const labels = lines.map(l => l.split(":")[0].trim());
      const data = lines.map(l => parseInt(l.split(":")[1].trim()));
      setChartData({
        labels,
        datasets: [{
          label: "Forecasted Workload",
          data,
          borderColor: 'green',
          borderWidth: 2,
          fill: false,
        }]
      });
    }
  };

  return (
    <div className="App" style={{ padding: 20 }}>
      <h2>Workload Forecast App</h2>
      <input type="file" accept=".csv" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload}>Upload & Forecast</button>
      <div style={{ marginTop: 30 }}>
        {chartData && <Line data={chartData} />}
        <pre style={{ marginTop: 20 }}>{forecast}</pre>
      </div>
    </div>
  );
}

export default App;
