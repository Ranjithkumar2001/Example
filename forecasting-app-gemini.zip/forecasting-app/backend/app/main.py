from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import csv
from typing import List
import os
import requests

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

def build_prompt(data: List[List[str]]) -> str:
    series = "\n".join([f"{row[0]}: {row[1]}" for row in data])
    return (
        f"Here is a time series of daily workload data:\n{series}\n\n"
        "Forecast the workload for the next 7 days and explain the trend. Respond with a JSON list followed by explanation."
    )

def call_gemini(prompt: str) -> str:
    endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"
    headers = {"Content-Type": "application/json"}
    payload = {
        "contents": [{"parts": [{"text": prompt}]}]
    }
    response = requests.post(f"{endpoint}?key={GEMINI_API_KEY}", headers=headers, json=payload)
    return response.json()["candidates"][0]["content"]["parts"][0]["text"]

@app.post("/forecast")
async def forecast(file: UploadFile = File(...)):
    content = await file.read()
    lines = content.decode().splitlines()
    reader = csv.reader(lines)
    next(reader)
    time_series = list(reader)

    prompt = build_prompt(time_series)
    result = call_gemini(prompt)
    return {"forecast_text": result}
